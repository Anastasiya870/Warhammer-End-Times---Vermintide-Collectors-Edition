# VermintideMods
Warhammer End Times: Vermintide mods I created. 
Requires the Quality of Life Modpack V15 or higher.

Each lua file is its own individual mod. To install, drop the files in the mods/patch folder and boot the game.