﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VermintideBundleTool")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("VermintideBundleTool")]
[assembly: AssemblyCopyright("Copyright © 2015 Atvaark")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("d8f4fea1-064d-45a3-a2ec-ea387f4341ba")]
[assembly: AssemblyVersion("0.2.1.0")]
[assembly: AssemblyFileVersion("0.2.1.0")]
